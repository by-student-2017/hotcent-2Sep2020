import warnings
from ase.neighborlist import NeighborList
__all__ = ['NeighborList']

warnings.warn('Moved to ase.neighborlist')
