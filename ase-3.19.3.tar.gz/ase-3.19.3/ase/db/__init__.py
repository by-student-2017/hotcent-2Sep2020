from ase.db.core import connect
__all__ = ['connect']
